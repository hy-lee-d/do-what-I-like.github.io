---
title: "Layout: Code Excerpt (Generated)"
categories:
  - Layout
  - Uncategorized
tags:
  - content
  - excerpt
  - layout
---

This is the post content with inline code, (e.g. `<span style="color: red;">red</span>`. It should be displayed in place of the auto-generated excerpt in single-page views. Archive-index pages should display an auto-generated excerpt of this content.

Be sure to test the formatting of the auto-generated excerpt, to ensure that it doesn't create any layout problems.