---
title: "Layout: Author Sidebar Disabled"
excerpt: "A post to test disabling author sidebar."
author_profile: false
---

This post has the author sidebar disabled.

To disable add `author_profile: false` to YAML Front Matter.